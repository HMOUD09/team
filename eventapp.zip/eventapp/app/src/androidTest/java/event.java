import android.provider.ContactsContract;

public class event {


    private int id;
    private String  name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(int dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassworld() {
        return passworld;
    }

    public void setPassworld(String passworld) {
        this.passworld = passworld;
    }

    public String getEcategories() {
        return ecategories;
    }

    public void setEcategories(String ecategories) {
        this.ecategories = ecategories;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public int geteDate() {
        return eDate;
    }

    public void seteDate(int eDate) {
        this.eDate = eDate;
    }

    public int geteDuration() {
        return eDuration;
    }

    public void seteDuration(int eDuration) {
        this.eDuration = eDuration;
    }

    public char geteLocation() {
        return eLocation;
    }

    public void seteLocation(char eLocation) {
        this.eLocation = eLocation;
    }

    public int geteSection() {
        return eSection;
    }

    public void seteSection(int eSection) {
        this.eSection = eSection;
    }

    public int geteChair() {
        return eChair;
    }

    public void seteChair(int eChair) {
        this.eChair = eChair;
    }

    public int geteTickeetPrice() {
        return eTickeetPrice;
    }

    public void seteTickeetPrice(int eTickeetPrice) {
        this.eTickeetPrice = eTickeetPrice;
    }

    public int gettId() {
        return tId;
    }

    public void settId(int tId) {
        this.tId = tId;
    }

    public int getaId() {
        return aId;
    }

    public void setaId(int aId) {
        this.aId = aId;
    }

    public event(int id, String name, String lastname, String gender, int dateOfBirth, String email, String passworld, String ecategories, String eventName, int eDate, int eDuration, char eLocation, int eSection, int eChair, int eTickeetPrice, int tId, int aId) {
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.passworld = passworld;
        this.ecategories = ecategories;
        this.eventName = eventName;
        this.eDate = eDate;
        this.eDuration = eDuration;
        this.eLocation = eLocation;
        this.eSection = eSection;
        this.eChair = eChair;
        this.eTickeetPrice = eTickeetPrice;
        this.tId = tId;
        this.aId = aId;
    }

    private String  lastname ;
    private String  gender ;
    private int dateOfBirth ;
    private String  email;
    private String  passworld;
    private String ecategories ;
    private String eventName ;
    private int eDate ;
    private int eDuration ;
    private char eLocation ;
    private int eSection ;
    private int eChair ;
    private int eTickeetPrice ;
    private int tId ;
    private int aId;



    public void AdminInfo (int aId, String name, String lastname ,String  gender , int dateOfBirth , String email,String  passworld  ) {
        this.aId = aId ;
        this.name = name;
        this.lastname = lastname;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.passworld = passworld;



    }


    public void UserInfo (int id, String name, String lastname ,String  gender , int dateOfBirth , String email,String  passworld  ) {
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.passworld = passworld;



    }


    public void EventInfo (int tId,String ecategorie,String eventName,int eDate,int eDuration,char eLocation,int eSection,int eChair , int eTickeetPrice  ) {
        this.tId = tId;
        this.ecategories = ecategorie;
        this.eventName = eventName;
        this.eDate = eDate;
        this.eDuration = eDuration;
        this.eLocation = eLocation ;
        this.eSection = eSection;
        this.eChair = eChair ;
        this.eTickeetPrice = eTickeetPrice;



    }


}